$( document ).ready(function() {
  $('.btn--menu').on('click', function() {
    $(this).toggleClass('is-active');
    if($(this).hasClass('is-active')) {
      $(this).find('._open').hide();
      $(this).find('._close').show();
    } else {
      $(this).find('._open').show();
      $(this).find('._close').hide();
    }
    $('#gnav').toggleClass('is-active');
  });
});